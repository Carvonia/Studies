# Por: Matheus Cunha Nogueira - 06004493
import random

for i in range(50):
    RandNum = random.randint(1, 100)
    print(RandNum)