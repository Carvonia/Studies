# Por: Matheus Cunha Nogueira - 06004493

for Num in range(10, 201, 2):
    print(Num)